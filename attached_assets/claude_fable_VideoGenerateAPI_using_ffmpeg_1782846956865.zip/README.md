# Image-to-Video API (with narration)

FastAPI service that turns images + a JSON spec into an MP4 slideshow with text
overlays and **optional spoken narration**. Rendering uses Pillow, encoding and
audio muxing use ffmpeg. Narration is synthesized offline with espeak-ng.

## Files

| file               | role                                                            |
|--------------------|-----------------------------------------------------------------|
| `main.py`          | FastAPI app, the `/videos` endpoint                             |
| `video_builder.py` | spec parsing, slide rendering (Pillow), H.264 encoding (ffmpeg) |
| `audio.py`         | per-slide narration + mux onto the silent video                 |
| `tts.py`           | offline text-to-speech via the bundled espeak-ng library        |

## Requirements

- Python 3.10+
- ffmpeg on PATH (`apt install ffmpeg` / `brew install ffmpeg`)
- `pip install -r requirements.txt` (espeak-ng ships inside the `espeakng-loader` wheel — no system package needed)

## Run

```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Endpoint

`POST /videos` — multipart form:

| field    | type            | description                          |
|----------|-----------------|--------------------------------------|
| `images` | file (repeated) | one or more images, in upload order  |
| `spec`   | string          | JSON describing the video (optional) |

Returns the MP4 (`video/mp4`). If any slide has a `narration` field, the result
includes a synced AAC audio track; otherwise it's a silent video.

## Spec format

```json
{
  "width": 1280,
  "height": 720,
  "fps": 30,
  "background": "#000000",
  "default_duration": 3.0,
  "slides": [
    {
      "image_index": 0,
      "duration": 15.0,
      "narration": "Spoken text for this slide, fit to its duration.",
      "texts": [
        { "text": "Tower Bridge", "position": "top", "font_size": 60,
          "color": "#FFFFFF", "background": "#000000AA" }
      ]
    }
  ]
}
```

Overlay options per text item: `position` (top/center/bottom), `font_size`,
`color`, `background` (RGBA hex for the caption box, or null), `margin`.
Limits: 50 images, 15 MB each, 0.1–60 s per slide, 300 s total, even width/height.

**Narration tip:** espeak speaks ~150 words/min, so ~35 words ≈ 15 s. Keep each
slide's narration a little under its duration so nothing gets clipped; the audio
step pads shorter clips automatically and fits each to the slide length.

## Example (4-slide narrated tour)

```bash
curl -X POST http://localhost:8000/videos \
  -F "images=@towerbridge.jpg" \
  -F "images=@londoneye.jpg" \
  -F "images=@westminster.jpg" \
  -F "images=@buckingham.jpg" \
  -F 'spec={
        "width":1280,"height":720,"fps":30,
        "slides":[
          {"image_index":0,"duration":15,"narration":"Tower Bridge opened in 1894...","texts":[{"text":"Tower Bridge","position":"top","font_size":60}]},
          {"image_index":1,"duration":15,"narration":"The London Eye is a giant observation wheel...","texts":[{"text":"The London Eye","position":"top","font_size":60}]},
          {"image_index":2,"duration":15,"narration":"The Palace of Westminster houses Parliament...","texts":[{"text":"Westminster","position":"top","font_size":60}]},
          {"image_index":3,"duration":15,"narration":"Buckingham Palace is the monarch'\''s London home...","texts":[{"text":"Buckingham Palace","position":"top","font_size":60}]}
        ]
      }' \
  -o london_tour.mp4
```

## Swapping the voice

`tts.py` uses espeak-ng, which is robotic but fully offline and dependency-free.
For natural narration, replace `synth_to_wav` with a call to a better engine —
e.g. **Piper** (local neural, download a `.onnx` voice) or a cloud API
(ElevenLabs, Google, Azure). `audio.py` only needs a function that writes a WAV
for a given string; nothing else changes.

## Production notes

- Generation is CPU-bound and synchronous. For real traffic, offload to a job
  queue (Celery/RQ) and return a job ID + download URL instead of blocking.
- Add an API key / auth and rate limiting before exposing publicly.
- Temp files are cleaned up after the response is sent via background tasks.
