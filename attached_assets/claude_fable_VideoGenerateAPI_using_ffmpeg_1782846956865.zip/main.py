"""
main.py — Image-to-Video API with optional narration audio.

Endpoints:
  GET  /health        liveness check
  POST /videos        images + JSON spec -> MP4 (narration optional, built into spec)

Run:
  uvicorn main:app --host 0.0.0.0 --port 8000

The spec is the same as before, with one addition: any slide may include a
"narration" string. If at least one slide has narration, the response MP4 has a
synced audio track; otherwise it's a silent video (identical to the original).
"""

import io
import json
import tempfile
import uuid
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from PIL import Image, UnidentifiedImageError

from video_builder import VideoSpec, build_video
from audio import add_narration

app = FastAPI(title="Image-to-Video API", version="2.0.0")

MAX_IMAGES = 50
MAX_IMAGE_BYTES = 15 * 1024 * 1024  # 15 MB each


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/videos")
async def create_video(
    background_tasks: BackgroundTasks,
    images: list[UploadFile] = File(..., description="One or more image files, in order"),
    spec: str = Form("{}", description="JSON string describing the video"),
):
    # ---- parse spec ----
    try:
        spec_dict = json.loads(spec)
        if not isinstance(spec_dict, dict):
            raise ValueError("spec must be a JSON object")
    except (json.JSONDecodeError, ValueError) as e:
        raise HTTPException(status_code=422, detail=f"Invalid spec JSON: {e}")

    # ---- load images ----
    if not images or len(images) > MAX_IMAGES:
        raise HTTPException(status_code=422, detail=f"Provide 1–{MAX_IMAGES} images")

    pil_images = []
    for i, up in enumerate(images):
        data = await up.read()
        if len(data) > MAX_IMAGE_BYTES:
            raise HTTPException(status_code=413, detail=f"Image {i} exceeds 15 MB")
        try:
            img = Image.open(io.BytesIO(data))
            img.load()
        except UnidentifiedImageError:
            raise HTTPException(status_code=422, detail=f"File {i} ({up.filename}) is not a valid image")
        pil_images.append(img)

    # ---- validate spec against images ----
    try:
        video_spec = VideoSpec.from_dict(spec_dict, num_images=len(pil_images))
    except (ValueError, TypeError, KeyError) as e:
        raise HTTPException(status_code=422, detail=str(e))

    # ---- pull narration per slide from the raw spec (aligned to spec.slides) ----
    raw_slides = spec_dict.get("slides")
    if raw_slides:
        narrations = [s.get("narration") for s in raw_slides]
    else:
        narrations = [None] * len(video_spec.slides)
    durations = [s.duration for s in video_spec.slides]
    has_audio = any(n and n.strip() for n in narrations)

    tmp = Path(tempfile.gettempdir())
    silent_path = tmp / f"silent_{uuid.uuid4().hex}.mp4"
    out_path = tmp / f"video_{uuid.uuid4().hex}.mp4"

    # ---- render silent video via the core API ----
    try:
        build_video(pil_images, video_spec, str(silent_path))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=f"video render failed: {e}")

    # ---- add narration if requested ----
    if has_audio:
        try:
            add_narration(str(silent_path), narrations, durations, str(out_path))
        except (RuntimeError, ValueError) as e:
            raise HTTPException(status_code=500, detail=f"audio step failed: {e}")
        background_tasks.add_task(silent_path.unlink, missing_ok=True)
        final = out_path
    else:
        final = silent_path

    background_tasks.add_task(final.unlink, missing_ok=True)
    return FileResponse(final, media_type="video/mp4", filename="output.mp4")
